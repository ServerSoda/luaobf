# LUA::OBSCURA — Public Web Edition

Rust + Axum web application prepared for deployment on Render using Docker.

## Current release scope

- Public browser UI
- Lua / Luau mode selection
- Conservative token-aware comment/whitespace minification
- Copy and `.lua` download
- 256 KiB source limit
- `/healthz` health endpoint
- Basic per-IP request throttling (30 requests / minute per process)
- No database and no intentional source persistence
- Docker deployment and Render Blueprint

## Important truth about protection

This release is **not yet a strong obfuscator**. It preserves identifiers, strings, and control flow. The Advanced and Extreme labels are roadmap placeholders. Do not market this release as unbreakable or production-grade source protection. A dialect-aware parser, AST passes, and differential tests are required before enabling semantic transformations.

## Deploy to Render

1. Push this folder to a GitHub repository.
2. Sign in to Render and connect that repository.
3. Choose **New + → Blueprint** and select the repository.
4. Render detects `render.yaml`; review the service and deploy.
5. Wait for the `/healthz` check to pass.
6. Open the generated `https://<service-name>.onrender.com` URL.

The service binds to `0.0.0.0:$PORT`, as required by Render's web service environment.

## Deploy locally with Docker

```bash
docker build -t lua-obscura .
docker run --rm -p 3000:3000 -e PORT=3000 lua-obscura
```

Open http://localhost:3000.

## Local development without Docker

Install Rust stable, then:

```bash
cargo run
```

Open http://localhost:3000.

## Operational notes

- The included in-memory rate limiter is per process and resets on restart. It is a basic abuse-control layer, not a substitute for edge-level rate limiting or a distributed limiter.
- For a public launch, add monitoring, stricter request validation, automated tests, and an external rate limiter before accepting substantial traffic.
- Avoid logging request bodies. The app logs HTTP metadata, not submitted source.
- No database is configured. Accounts and usage history are intentionally deferred.
- Free hosting availability, sleep behavior, and quotas can change; check Render's current plan details before launch.
