use axum::{
    extract::{ConnectInfo, Json, Request},
    http::{header, HeaderValue, Method, StatusCode},
    middleware::{self, Next},
    response::{Html, IntoResponse, Response},
    routing::{get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, net::SocketAddr, sync::{Arc, Mutex}, time::{Duration, Instant}};
use tower_http::{limit::RequestBodyLimitLayer, trace::TraceLayer};

const MAX_SOURCE_BYTES: usize = 256 * 1024;
const RATE_LIMIT: u32 = 30;
const RATE_WINDOW: Duration = Duration::from_secs(60);

#[derive(Clone)]
struct AppState {
    hits: Arc<Mutex<HashMap<String, Vec<Instant>>>>,
}

#[derive(Deserialize)]
struct ObfuscateRequest {
    source: String,
    dialect: Option<String>,
    preset: Option<String>,
}

#[derive(Serialize)]
struct ObfuscateResponse {
    output: String,
    warnings: Vec<String>,
    stats: Stats,
}

#[derive(Serialize)]
struct Stats {
    input_bytes: usize,
    output_bytes: usize,
    reduction_percent: f64,
}

#[derive(Serialize)]
struct ErrorBody {
    error: String,
}

async fn index() -> Html<&'static str> {
    Html(include_str!("../static/index.html"))
}

async fn health() -> impl IntoResponse {
    (StatusCode::OK, "ok")
}

async fn rate_limit(
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    request: Request,
    next: Next,
) -> Response {
    let state = request.extensions().get::<AppState>().cloned();
    if let Some(state) = state {
        let key = addr.ip().to_string();
        let now = Instant::now();
        let mut hits = state.hits.lock().expect("rate-limit mutex poisoned");
        let entries = hits.entry(key).or_default();
        entries.retain(|t| now.duration_since(*t) < RATE_WINDOW);
        if entries.len() >= RATE_LIMIT {
            return (StatusCode::TOO_MANY_REQUESTS, Json(ErrorBody {
                error: "Rate limit exceeded. Try again in a minute.".into()
            })).into_response();
        }
        entries.push(now);
        if hits.len() > 10_000 {
            hits.retain(|_, v| !v.is_empty());
        }
    }
    next.run(request).await
}

async fn obfuscate(Json(req): Json<ObfuscateRequest>) -> Result<Json<ObfuscateResponse>, (StatusCode, Json<ErrorBody>)> {
    if req.source.len() > MAX_SOURCE_BYTES {
        return Err((StatusCode::PAYLOAD_TOO_LARGE, Json(ErrorBody {
            error: format!("Source exceeds the {} KiB limit.", MAX_SOURCE_BYTES / 1024)
        })));
    }
    let dialect = req.dialect.as_deref().unwrap_or("lua");
    if !matches!(dialect, "lua" | "luau") {
        return Err((StatusCode::BAD_REQUEST, Json(ErrorBody { error: "dialect must be lua or luau".into() })));
    }

    // Conservative token-aware minification. Full obfuscation awaits a dialect-aware AST.
    let output = minify(&req.source).map_err(|e| (StatusCode::BAD_REQUEST, Json(ErrorBody { error: e })))?;
    let input_bytes = req.source.len();
    let output_bytes = output.len();
    let reduction_percent = if input_bytes == 0 { 0.0 } else {
        ((input_bytes.saturating_sub(output_bytes)) as f64 / input_bytes as f64) * 100.0
    };

    let mut warnings = vec![
        "Current engine performs conservative comment and whitespace minification only.".to_string(),
        "Identifiers, strings, and control flow are unchanged; this is not strong obfuscation yet.".to_string(),
        "Do not submit secrets, credentials, or private source code to a public service.".to_string(),
    ];
    if req.preset.as_deref().unwrap_or("basic") != "basic" {
        warnings.push("Advanced/Extreme presets are UI roadmap options and are not active in this release.".to_string());
    }

    Ok(Json(ObfuscateResponse {
        output,
        warnings,
        stats: Stats { input_bytes, output_bytes, reduction_percent },
    }))
}

#[derive(Clone, Copy, PartialEq)]
enum State { Code, ShortString(u8), LongString(usize), LineComment, LongComment(usize) }

fn long_bracket_open(bytes: &[u8], i: usize) -> Option<(usize, usize)> {
    if bytes.get(i) != Some(&b'[') { return None; }
    let mut j = i + 1;
    while bytes.get(j) == Some(&b'=') { j += 1; }
    if bytes.get(j) == Some(&b'[') { Some((j - i - 1, j + 1)) } else { None }
}
fn long_bracket_close(bytes: &[u8], i: usize, eqs: usize) -> Option<usize> {
    if bytes.get(i) != Some(&b']') { return None; }
    let mut j = i + 1;
    for _ in 0..eqs { if bytes.get(j) != Some(&b'=') { return None; } j += 1; }
    if bytes.get(j) == Some(&b']') { Some(j + 1) } else { None }
}
fn is_word(b: u8) -> bool { b.is_ascii_alphanumeric() || b == b'_' || b >= 0x80 }

fn minify(src: &str) -> Result<String, String> {
    let b = src.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0usize;
    let mut state = State::Code;
    let mut pending_space = false;
    while i < b.len() {
        match state {
            State::Code => {
                if b[i].is_ascii_whitespace() { pending_space = true; i += 1; continue; }
                if b[i] == b'-' && b.get(i+1) == Some(&b'-') {
                    if let Some((eqs, content_start)) = long_bracket_open(b, i+2) {
                        state = State::LongComment(eqs); i = content_start;
                    } else { state = State::LineComment; i += 2; }
                    continue;
                }
                if pending_space {
                    // Keeping one separator is intentionally conservative: deleting
                    // whitespace between punctuation can merge Lua operators/tokens.
                    if !out.is_empty() { out.push(b' '); }
                    pending_space = false;
                }
                if b[i] == b'\'' || b[i] == b'"' {
                    let q = b[i]; out.push(q); i += 1; state = State::ShortString(q); continue;
                }
                if b[i] == b'[' {
                    if let Some((eqs, content_start)) = long_bracket_open(b, i) {
                        out.extend_from_slice(&b[i..content_start]); i = content_start;
                        state = State::LongString(eqs); continue;
                    }
                }
                out.push(b[i]); i += 1;
            }
            State::ShortString(q) => {
                let c = b[i]; out.push(c); i += 1;
                if c == b'\\' && i < b.len() { out.push(b[i]); i += 1; }
                else if c == q { state = State::Code; }
            }
            State::LineComment => {
                if b[i] == b'\n' { state = State::Code; pending_space = true; }
                i += 1;
            }
            State::LongString(eqs) => {
                if let Some(end) = long_bracket_close(b, i, eqs) {
                    out.extend_from_slice(&b[i..end]); i = end; state = State::Code;
                } else { out.push(b[i]); i += 1; }
            }
            State::LongComment(eqs) => {
                if let Some(end) = long_bracket_close(b, i, eqs) {
                    i = end; state = State::Code; pending_space = true;
                } else { i += 1; }
            }
        }
    }
    if matches!(state, State::ShortString(_) | State::LongString(_)) {
        return Err("Unterminated string literal.".into());
    }
    String::from_utf8(out).map_err(|_| "Input must be valid UTF-8.".to_string())
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(std::env::var("RUST_LOG").unwrap_or_else(|_| "info,tower_http=info".into()))
        .init();

    let state = AppState { hits: Arc::new(Mutex::new(HashMap::new())) };
    let app = Router::new()
        .route("/", get(index))
        .route("/healthz", get(health))
        .route("/api/obfuscate", post(obfuscate))
        .layer(middleware::from_fn(rate_limit))
        .layer(RequestBodyLimitLayer::new(MAX_SOURCE_BYTES + 16 * 1024))
        .layer(TraceLayer::new_for_http())
        .with_state(state.clone())
        .layer(axum::Extension(state));

    let port: u16 = std::env::var("PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(3000);
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    let listener = tokio::net::TcpListener::bind(addr).await.expect("bind failed");
    tracing::info!("LUA::OBSCURA listening on {addr}");
    axum::serve(listener, app.into_make_service_with_connect_info::<SocketAddr>())
        .await.expect("server failed");
}
